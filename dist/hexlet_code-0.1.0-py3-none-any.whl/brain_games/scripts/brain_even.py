#!/usr/bin/env python3

from brain_games.even_module import game


def main():
    game()


if __name__ == '__main__':
    main()
